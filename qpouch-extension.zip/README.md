# QPouch - community wallet for QMS Testnet (unofficial)

## Install (developer mode)
1. In this folder, add the crypto library (version 5.7.2). In PowerShell, from this folder:
   `Invoke-WebRequest https://cdnjs.cloudflare.com/ajax/libs/ethers/5.7.2/ethers.umd.min.js -OutFile ethers.umd.min.js`
   Optional: `Get-FileHash -Algorithm SHA384 ethers.umd.min.js` and compare the hash with the SRI value shown for ethers 5.7.2 on cdnjs.com.
2. Open chrome://extensions, enable Developer mode, click Load unpacked, choose this folder (the one containing manifest.json).
3. Create or import a wallet from the toolbar icon. On a dApp, choose "QPouch" or the injected/browser wallet option.

Supports QMS Testnet (chain 19480) only. Unlock once; locks after 1 hour idle or when the browser closes.
Unofficial and not independently audited. Do not use with real funds.
